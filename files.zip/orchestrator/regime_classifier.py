class RegimeClassifier:
    def __init__(self, config):
        pass

    def classify(self, snapshot):
        # TODO: Use ATR, SMA slope, ADX, IV rank, etc.
        return "CALM"