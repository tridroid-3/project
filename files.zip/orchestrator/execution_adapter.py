class ExecutionAdapter:
    def __init__(self, config):
        self.config = config

    def send_orders(self, orders, tag=""):
        # TODO: Plug in actual webhook/broker call here
        print(f"EXECUTE: {orders} | tag={tag}")
        return True, "stub"

    def get_position_status(self):
        return {}