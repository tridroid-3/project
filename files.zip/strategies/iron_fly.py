from strategies.base_strategy import BaseStrategy
import datetime
import re

class IronFlyStrategy(BaseStrategy):
    def __init__(self, config, logger):
        super().__init__(config, logger)
        self.name = "iron_fly"
        self.open_positions = []
        self.last_atm = None
        self.in_position = False
        self.baseline_ce_ltp = None
        self.baseline_pe_ltp = None
        self.last_ce_action = None
        self.last_pe_action = None
        self.realized_ce_mtm = 0.0
        self.realized_pe_mtm = 0.0
        self.otm_legs = {}

        self.STRIKE_STEP = config.get("STRIKE_STEP", 100)
        self.LOT_SIZE = config.get("LOT_SIZE", 20)
        self.MESSAGE_LOTS = config.get("MESSAGE_LOTS", 1)
        self.STOPLOSS_PER_LOT = config.get("iron_fly", {}).get("stoploss_per_lot", 3000)
        self.TARGET_PER_LOT = config.get("iron_fly", {}).get("target_per_lot", 10000)
        self.WING_FACTOR = config.get("iron_fly", {}).get("wing_factor", 1.0)
        self.OTM_EXIT_PCT = config.get("iron_fly", {}).get("otm_exit_pct", 25.0)
        self.SYMBOL = config.get("SYMBOL", "SENSEX")
        self.EXPIRY_DATE = config["upstox"]["expiry_date"]

    def can_enter(self, snapshot, regime):
        ce_ltp = snapshot.get("ce_ltp", 0.0)
        pe_ltp = snapshot.get("pe_ltp", 0.0)
        if self.in_position:
            return False, "Already in position", {}
        if ce_ltp > 0.0 and pe_ltp > 0.0:
            if regime in ["CALM", "TRANSITION"]:
                return True, "Entry conditions met", {}
            else:
                return False, f"Regime {regime} not suitable", {}
        return False, "LTPs not valid", {}

    def enter(self, snapshot, params):
        atm_strike = snapshot["atm_strike"]
        spot = snapshot["spot"]
        ce_instr = self._build_option_symbol(atm_strike, "C")
        pe_instr = self._build_option_symbol(atm_strike, "P")
        ce_ltp = snapshot["ce_ltp"]
        pe_ltp = snapshot["pe_ltp"]
        iv = snapshot.get("iv_estimates", 15.0)
        otm_distance = self._calculate_otm_distance(spot, iv, self.STRIKE_STEP)
        otm_ce_strike = atm_strike + otm_distance
        otm_pe_strike = atm_strike - otm_distance
        otm_ce_instr = self._build_option_symbol(otm_ce_strike, "C")
        otm_pe_instr = self._build_option_symbol(otm_pe_strike, "P")
        otm_ce_ltp = self._get_ltp_for_instrument(snapshot["option_chain"], otm_ce_instr)
        otm_pe_ltp = self._get_ltp_for_instrument(snapshot["option_chain"], otm_pe_instr)

        payloads = [
            {"action": "sell", "instrument": ce_instr, "lots": self.MESSAGE_LOTS},
            {"action": "sell", "instrument": pe_instr, "lots": self.MESSAGE_LOTS},
        ]
        if otm_ce_ltp > 0:
            payloads.append({"action": "buy", "instrument": otm_ce_instr, "lots": self.MESSAGE_LOTS})
            self.otm_legs[otm_ce_instr] = otm_ce_ltp
        if otm_pe_ltp > 0:
            payloads.append({"action": "buy", "instrument": otm_pe_instr, "lots": self.MESSAGE_LOTS})
            self.otm_legs[otm_pe_instr] = otm_pe_ltp

        self.open_positions = [
            {"instrument": ce_instr, "side": "S", "entry_price": ce_ltp, "quantity": self.MESSAGE_LOTS, "mtm": 0.0},
            {"instrument": pe_instr, "side": "S", "entry_price": pe_ltp, "quantity": self.MESSAGE_LOTS, "mtm": 0.0},
        ]
        self.last_atm = atm_strike
        self.in_position = True
        self.baseline_ce_ltp = ce_ltp
        self.baseline_pe_ltp = pe_ltp
        self.last_ce_action = "S"
        self.last_pe_action = "S"
        return payloads

    def on_tick(self, snapshot, position):
        ce_leg_mtm = 0.0
        pe_leg_mtm = 0.0
        for pos in self.open_positions:
            instr = pos["instrument"]
            entry_price = pos["entry_price"]
            side = pos["side"]
            lots = pos["quantity"]
            curr_ltp = self._get_ltp_for_instrument(snapshot["option_chain"], instr)
            if entry_price is None or entry_price == 0.0:
                pos["mtm"] = 0.0
                continue
            mtm = (entry_price - curr_ltp) * lots * self.LOT_SIZE if side == "S" else (curr_ltp - entry_price) * lots * self.LOT_SIZE
            pos["mtm"] = mtm
            if instr.endswith("C"): ce_leg_mtm += mtm
            elif instr.endswith("P"): pe_leg_mtm += mtm
        total_mtm = ce_leg_mtm + pe_leg_mtm + self.realized_ce_mtm + self.realized_pe_mtm

        if total_mtm <= -self.STOPLOSS_PER_LOT * self.MESSAGE_LOTS * self.LOT_SIZE:
            self.logger.log_exit(position, "stoploss")
            return {"reason": "stoploss", "positions": self.open_positions.copy()}
        elif total_mtm >= self.TARGET_PER_LOT * self.MESSAGE_LOTS * self.LOT_SIZE:
            self.logger.log_exit(position, "target")
            return {"reason": "target", "positions": self.open_positions.copy()}

        otm_exit_orders = []
        for otm_instr, baseline in list(self.otm_legs.items()):
            curr_ltp = self._get_ltp_for_instrument(snapshot["option_chain"], otm_instr)
            if baseline <= 0: continue
            change_pct = ((curr_ltp - baseline)/baseline)*100
            if abs(change_pct) >= self.OTM_EXIT_PCT:
                otm_exit_orders.append({"action": "sell", "instrument": otm_instr, "lots": self.MESSAGE_LOTS})
                self.otm_legs.pop(otm_instr, None)
        if otm_exit_orders:
            return {"reason": "otm_exit", "orders": otm_exit_orders}
        return None

    def exit(self, position, exits):
        orders = []
        for pos in self.open_positions:
            orders.append({"action": "buy", "instrument": pos["instrument"], "lots": pos["quantity"]})
        for otm_instr in list(self.otm_legs.keys()):
            orders.append({"action": "sell", "instrument": otm_instr, "lots": self.MESSAGE_LOTS})
        self.open_positions = []
        self.in_position = False
        self.otm_legs.clear()
        self.baseline_ce_ltp = None
        self.baseline_pe_ltp = None
        self.last_ce_action = None
        self.last_pe_action = None
        return orders

    def get_open_positions(self):
        return self.open_positions

    def _build_option_symbol(self, strike, opt_type):
        yymmdd = self.EXPIRY_DATE.replace("-", "")[2:]
        return f"{self.SYMBOL}{yymmdd}{opt_type}{int(strike)}"

    def _calculate_otm_distance(self, spot, iv_pct, step):
        if iv_pct <= 0.0:
            iv_pct = 15.0
        distance = round(spot * iv_pct / 100.0 / step) * step
        return max(distance, step)

    def _get_ltp_for_instrument(self, data, instrument):
        m = re.match(r"([A-Z]+)(\d{6})([CP])(\d+)", instrument)
        if not m:
            return 0.0
        _, yymmdd, opt_type, strike = m.groups()
        strike = int(strike)
        for item in data:
            s = item.get("strike_price") or item.get("strike")
            if s is None:
                continue
            try:
                if int(s) != strike:
                    continue
            except:
                continue
            if opt_type == "C":
                ce = item.get("call_options", {}).get("market_data", {})
                ltp = ce.get("ltp")
            else:
                pe = item.get("put_options", {}).get("market_data", {})
                ltp = pe.get("ltp")
            try:
                return float(ltp)
            except:
                return 0.0
        return 0.0